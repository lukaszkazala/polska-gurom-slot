from .config import *

__version__ = "0.4.0-weighted"
