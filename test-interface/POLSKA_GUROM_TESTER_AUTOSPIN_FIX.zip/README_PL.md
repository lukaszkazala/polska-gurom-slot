# POLSKA GUROM — tester interfejsu

## Uruchomienie

1. Wypakuj **całe archiwum ZIP** do własnego folderu. Silnik gry jest już w paczce.
2. Potrzebny jest **Python 3.12 lub nowszy**. Nie trzeba instalować dodatkowych pakietów. Na tym komputerze uruchamiacz może też użyć Pythona dołączonego do aplikacji Codex.
3. Kliknij dwukrotnie **START.cmd**. Otworzy się przeglądarka z adresem **http://127.0.0.1:8765**. Jeśli nie otworzy się automatycznie, wpisz ten adres samodzielnie.
4. Pozostaw otwarte okno uruchamiacza podczas testów. Aby zakończyć, naciśnij w nim **Ctrl+C**.

Gdy brakuje Pythona, zainstaluj go z [python.org](https://www.python.org/downloads/) i zaznacz opcję **Add python.exe to PATH**. Gdy port jest zajęty, zamknij wcześniejsze okno testera. Możesz też uruchomić w tym folderze `python server.py --port 8766` i otworzyć wskazany adres. Opcja `--no-browser` wyłącza automatyczne otwarcie przeglądarki.

## Co można testować

- Ręczne obroty, zmianę stawki, saldo, historię wyników, darmowe obroty, tabelę wypłat i wybór języka.
- Stawki podaje się w **pełnych złotych**. Saldo jest fikcyjne; tester nie obsługuje wpłat ani prawdziwych pieniędzy.
- Przycisk **ZAKRĘĆ / SPIN** lub **spacja** uruchamia obrót. Spacja jest pomijana podczas wpisywania w pola i wyboru ustawień.
- Przycisk **AUTO** otwiera okno ustawień autoplay. Wybierz **10, 25, 50, 100, 250 lub 500 płatnych rund** i uruchom serię. Jedna runda obejmuje płatny obrót oraz wszystkie przyznane mu darmowe obroty; bonus nie pomniejsza osobno licznika serii.
- **STOP AUTO** kończy serię po bieżącej rundzie, razem z jej bonusem. Zmiana karty lub ukrycie okna nie anuluje serii; przeglądarka może wtedy spowolnić obroty. Licznik pokazuje wykonane rundy, np. **80 / 100**, a po pełnej serii **100 / 100**.
- Przejściowy błąd połączenia powoduje maksymalnie trzy próby odczytu tej samej rundy, bez ponownego pobrania stawki. Gdy brakuje salda lub odczyt nadal się nie udaje, przy liczniku pozostaje powód przerwania serii.
- Dostępne tempa to **normalne, szybkie i turbo**. Przycisk szybkości przełącza tempo, a opcje w oknie AUTO pozwalają wybrać szybkie animacje lub turbo. Opcja **Pomijaj ekrany** pomija wejście do bonusu i jego ekran końcowy.
- **Tryb błyskawiczny** w oknie AUTO pokazuje od razu wynik całej rundy, razem z bonusem. Szybkość, pomijanie ekranów i tryb błyskawiczny zmieniają wyłącznie prezentację; nie zmieniają losowań, prawdopodobieństw ani rozliczenia wygranej.
- Przygotowane scenariusze służą do sprawdzania wyglądu wygranych i bonusów. **Nie zmieniają salda ani statystyk normalnej gry.**

Normalna gra korzysta z dołączonego silnika **v0.2**. Bonus przyznaje **8, 10 lub 12 darmowych obrotów**. Mnożnik **×4 dotyczy tylko wygranych liniowych**. Limit wygranej rundy wynosi **5000× stawka**. Scatter jest liczony przed rozszerzeniem symboli; darmowych obrotów nie można ponownie wyzwolić w bonusie. To narzędzie do testowania, a nie certyfikat poprawności lub dopuszczenia gry.

W matematyce **v0.2 nie ma zakupu darmowych obrotów ani opcji Double Chance**. Bonus jest przyznawany przez Scattery w zwykłej grze; podgląd scenariusza bonusowego służy wyłącznie testowaniu.

## Dodawanie własnych grafik

Najprościej użyj przycisku wgrywania grafik w interfejsie i wybierz pliki nazwane dokładnie:

`L1.png`, `L2.png`, `L3.png`, `L4.png`, `P1.png`, `P2.png`, `P3.png`, `P4.png`, `WILD.png`, `SCATTER.png`.

Grafiki wgrane w przeglądarce działają **do odświeżenia strony**. Można wgrać dowolny podzbiór symboli; pozostałe zachowają wygląd zastępczy.

Aby zachować grafiki na stałe, skopiuj je do folderu **web/assets/**. Następnie w pliku **web/assets/symbols.json** ustaw dla danego symbolu pole `image` na nazwę pliku, np. `"image": "L1.png"`. Możesz też użyć podfolderu, np. `"image": "symbols/diament.png"` — ścieżka jest liczona od folderu **assets**. Zapisz plik i odśwież stronę. W tym samym pliku można zmienić nazwy symboli po polsku, angielsku i niemiecku.

| Kod | Symbol |
| --- | --- |
| L1 | Diament |
| L2 | Pik |
| L3 | Serce |
| L4 | Trefl |
| P1 | Lilia |
| P2 | Kielich |
| P3 | Korona |
| P4 | Husarz |
| WILD | Wild |
| SCATTER | Scatter |
