# Local UX artwork — 20.10.2026

All four images were generated with the built-in imagegen tool for this project. Exact prompts and generation/edit history are in the project conversation. No downloaded third-party photographs or museum reproductions were supplied to the generation calls. This is provenance documentation, not a licence grant or legal clearance.

- `polskie-motywy.png`: texture atlas generated from text, nine illustrated objects. Game uses eight new folklore subjects from it; the ninth hussar drawing is not used. Generated file: exec-03b8e55d-a275-41f7-94ca-43650ded0fba.png.
- `rama.png`: ornamental frame generated from text. Generated file: exec-ce639e46-74ec-463e-8389-60eecac2214d.png. Browser uses nine-slice borders and excludes the centre.
- `husarz.png`: original helmet-and-wing shield, generated from text. Generated file: exec-002cf92e-5095-498c-945b-bd644ecbb365.png.
- `klasyczne-motywy.png`: the project's generated v5 concept, edited from earlier project-generated concepts. Generated file: exec-5e1387c7-60aa-42b0-af87-8b22323edf50.png. Only the existing card suits, lily, goblet, crown, WILD and SCATTER regions are displayed.

Images are stored unchanged. `art-catalog.js` defines rectangular source viewports. SVG clipping isolates the required regions during display, without editing source pixels. The gallery contains 18 distinct used illustrations, not every object or ornament visible in the source atlases.

No official eagle emblems were deliberately included in the displayed art. No manufacturer names, logos or model labels are used for the small car illustration. The car's appearance and name, regional food names, similarity to other art, applicable tool terms and commercial distribution rights remain subject to final review before publication. A missing logo does not alone clear a vehicle design. These assets are provided here for the user's local, virtual-balance UX testing.
