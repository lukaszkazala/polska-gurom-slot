from __future__ import annotations

SYMBOLS = ("L1","L2","L3","L4","P1","P2","P3","P4","WILD","SCATTER")
REGULAR_SYMBOLS = SYMBOLS[:8]
WILD = "WILD"
SCATTER = "SCATTER"
ROWS = 3
REELS = 5
MAX_WIN = 5000.0
EXPANDING_WILD_PROBABILITY = 0.25  # prototype parameter; not math-frozen
FREE_SPINS = {3: 8, 4: 10, 5: 12}
SCATTER_PAYTABLE = {3: 1.0, 4: 5.0, 5: 20.0}

# Multiples of TOTAL BET. Prototype values, intentionally not math-frozen.
PAYTABLE = {
    "L1": {3: 0.20, 4: 0.80, 5: 2.50},
    "L2": {3: 0.25, 4: 1.00, 5: 3.50},
    "L3": {3: 0.30, 4: 1.20, 5: 4.50},
    "L4": {3: 0.40, 4: 1.60, 5: 6.00},
    "P1": {3: 0.60, 4: 2.50, 5: 10.00},
    "P2": {3: 0.80, 4: 3.50, 5: 15.00},
    "P3": {3: 1.20, 4: 5.50, 5: 25.00},
    "P4": {3: 2.00, 4: 10.00, 5: 50.00},
}

# 20 fixed paylines, row indices 0..2 from reel 1 to reel 5.
PAYLINES = (
    (1,1,1,1,1), (0,0,0,0,0), (2,2,2,2,2),
    (0,1,2,1,0), (2,1,0,1,2),
    (0,0,1,2,2), (2,2,1,0,0),
    (1,0,0,0,1), (1,2,2,2,1),
    (0,1,1,1,0), (2,1,1,1,2),
    (1,0,1,2,1), (1,2,1,0,1),
    (0,1,0,1,0), (2,1,2,1,2),
    (1,1,0,1,1), (1,1,2,1,1),
    (0,2,0,2,0), (2,0,2,0,2),
    (0,2,2,2,0),
)

# Every strip has 36 stops with the same composition but a different ordering.
# Composition per reel: L1 7, L2 5, L3 5, L4 4, P1 4, P2 3, P3 3,
# P4 2, WILD 2, SCATTER 1.
_BASE = [
    "L1","P1","L2","L3","WILD","L1","P2","L4","L2","P3","L1","P1",
    "L3","P4","L2","L1","P2","L4","L3","P1","L1","P3","L2","WILD",
    "L4","L1","P4","L3","P1","L2","P2","L4","L3","P3","L1","SCATTER",
]

def _rotate(seq, n):
    n %= len(seq)
    return tuple(seq[n:] + seq[:n])

REEL_STRIPS = (
    tuple(_BASE),
    _rotate(_BASE, 7),
    _rotate(_BASE, 13),
    _rotate(_BASE, 19),
    _rotate(_BASE, 27),
)
