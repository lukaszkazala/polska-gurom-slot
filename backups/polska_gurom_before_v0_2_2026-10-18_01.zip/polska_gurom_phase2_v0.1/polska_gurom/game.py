from __future__ import annotations
from dataclasses import dataclass
import random
from .config import (
    REEL_STRIPS, PAYLINES, PAYTABLE, REGULAR_SYMBOLS, WILD, SCATTER,
    SCATTER_PAYTABLE, FREE_SPINS, MAX_WIN, EXPANDING_WILD_PROBABILITY,
)

@dataclass(frozen=True)
class SpinResult:
    payout: float
    line_payout: float
    scatter_payout: float
    scatter_count: int
    bonus_triggered: bool
    free_spins_awarded: int
    expanding_reel: int | None = None


def window_for_stop(strip: tuple[str, ...], stop: int) -> tuple[str, str, str]:
    n = len(strip)
    return (strip[stop % n], strip[(stop + 1) % n], strip[(stop + 2) % n])


def generate_grid(rng: random.Random) -> list[list[str]]:
    # grid[row][reel]
    cols = [window_for_stop(strip, rng.randrange(len(strip))) for strip in REEL_STRIPS]
    return [[cols[c][r] for c in range(5)] for r in range(3)]


def _line_best_win(symbols: list[str]) -> float:
    best = 0.0
    for target in REGULAR_SYMBOLS:
        count = 0
        for symbol in symbols:
            if symbol == target or symbol == WILD:
                count += 1
            else:
                break
        if count >= 3:
            best = max(best, PAYTABLE[target][min(count, 5)])
    return best


def evaluate_lines(grid: list[list[str]]) -> float:
    total = 0.0
    for line in PAYLINES:
        symbols = [grid[line[reel]][reel] for reel in range(5)]
        total += _line_best_win(symbols)
    return total


def count_scatter(grid: list[list[str]]) -> int:
    return sum(cell == SCATTER for row in grid for cell in row)


def scatter_payout(count: int) -> float:
    return SCATTER_PAYTABLE.get(min(count, 5), 0.0) if count >= 3 else 0.0


def free_spins_for_scatter(count: int) -> int:
    return FREE_SPINS.get(min(count, 5), 0) if count >= 3 else 0


def apply_expanding_wild(grid: list[list[str]], reel_index: int) -> list[list[str]]:
    out = [row[:] for row in grid]
    for row in range(3):
        out[row][reel_index] = WILD
    return out


def cap_payout(value: float) -> float:
    return min(value, MAX_WIN)


def evaluate_paid_spin(grid: list[list[str]]) -> SpinResult:
    sc = count_scatter(grid)
    lp = evaluate_lines(grid)
    sp = scatter_payout(sc)
    fs = free_spins_for_scatter(sc)
    payout = cap_payout(lp + sp)
    return SpinResult(payout, lp, sp, sc, fs > 0, fs)


def evaluate_free_spin(grid: list[list[str]], rng: random.Random,
                       expansion_probability: float = EXPANDING_WILD_PROBABILITY) -> SpinResult:
    # Prototype convention: Scatter count/payout is evaluated on the original reel window.
    # Expansion affects payline evaluation only. Retriggers are intentionally disabled.
    sc = count_scatter(grid)
    sp = scatter_payout(sc)
    expanding_reel = None
    eval_grid = grid
    if rng.random() < expansion_probability:
        expanding_reel = rng.choice((1, 2, 3))  # reels 2,3,4 in 1-based language
        eval_grid = apply_expanding_wild(grid, expanding_reel)
    lp = evaluate_lines(eval_grid)
    payout = cap_payout(lp + sp)
    return SpinResult(payout, lp, sp, sc, False, 0, expanding_reel)


def play_round(rng: random.Random,
               expansion_probability: float = EXPANDING_WILD_PROBABILITY) -> tuple[SpinResult, float, int]:
    base = evaluate_paid_spin(generate_grid(rng))
    bonus_payout = 0.0
    expansions = 0
    for _ in range(base.free_spins_awarded):
        fs = evaluate_free_spin(generate_grid(rng), rng, expansion_probability)
        bonus_payout += fs.payout
        expansions += fs.expanding_reel is not None
    total = cap_payout(base.payout + bonus_payout)
    return base, total - base.payout, expansions
