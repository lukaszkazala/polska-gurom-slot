from __future__ import annotations
from collections import Counter
import math, random
from .config import REEL_STRIPS, WILD, SCATTER, MAX_WIN, EXPANDING_WILD_PROBABILITY
from .game import generate_grid, evaluate_paid_spin, evaluate_free_spin


def _bucket(x: float) -> str:
    if x == 0: return "0x"
    if x < 1: return ">0x-1x"
    if x < 5: return "1x-5x"
    if x < 20: return "5x-20x"
    if x < 100: return "20x-100x"
    if x < 500: return "100x-500x"
    if x < 1000: return "500x-1000x"
    if x < 5000: return "1000x+"
    return "5000x Max Win"


def simulate(n: int, seed: int = 20261015,
             expansion_probability: float = EXPANDING_WILD_PROBABILITY) -> dict:
    rng = random.Random(seed)
    sum_total = sum_sq = sum_base = sum_bonus = 0.0
    hit = bonus_count = total_fs = expansions = 0
    max_win = 0.0
    wild_cells = scatter_cells = total_cells = 0
    scatter_dist = Counter()
    buckets = Counter()

    for _ in range(n):
        grid = generate_grid(rng)
        wild_cells += sum(c == WILD for row in grid for c in row)
        scatter_cells += sum(c == SCATTER for row in grid for c in row)
        total_cells += 15
        base = evaluate_paid_spin(grid)
        bonus = 0.0
        if base.bonus_triggered:
            bonus_count += 1
            total_fs += base.free_spins_awarded
            for _ in range(base.free_spins_awarded):
                fg = generate_grid(rng)
                fs = evaluate_free_spin(fg, rng, expansion_probability)
                bonus += fs.payout
                expansions += fs.expanding_reel is not None
        total = min(base.payout + bonus, MAX_WIN)
        # Allocate any cap reduction against bonus first for accounting consistency.
        capped_bonus = max(0.0, total - base.payout)
        sum_base += base.payout
        sum_bonus += capped_bonus
        sum_total += total
        sum_sq += total*total
        hit += total > 0
        max_win = max(max_win, total)
        scatter_dist[base.scatter_count] += 1
        buckets[_bucket(total)] += 1

    mean = sum_total/n
    variance = max(0.0, sum_sq/n - mean*mean)
    return {
        "seed": seed, "spins": n,
        "rtp": mean,
        "base_rtp": sum_base/n,
        "bonus_rtp": sum_bonus/n,
        "hit_frequency": hit/n,
        "bonus_frequency": bonus_count/n,
        "average_bonus_payout": (sum_bonus/bonus_count if bonus_count else 0.0),
        "variance": variance,
        "std_dev": math.sqrt(variance),
        "max_observed_win": max_win,
        "free_spins_played": total_fs,
        "expanding_wild_events": expansions,
        "wild_cell_frequency": wild_cells/total_cells,
        "scatter_cell_frequency": scatter_cells/total_cells,
        "scatter_distribution": dict(sorted(scatter_dist.items())),
        "win_buckets": dict(buckets),
    }
