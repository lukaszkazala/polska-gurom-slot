from __future__ import annotations
from collections import Counter, defaultdict
from itertools import product
from .config import REEL_STRIPS, REGULAR_SYMBOLS, WILD, PAYTABLE, PAYLINES, SCATTER, SCATTER_PAYTABLE, FREE_SPINS, EXPANDING_WILD_PROBABILITY
from .game import _line_best_win, window_for_stop


def symbol_probabilities():
    return [{s: strip.count(s)/len(strip) for s in set(strip)} for strip in REEL_STRIPS]


def expected_line_payout(forced_wild_reel: int | None = None) -> float:
    probs = symbol_probabilities()
    symbols = sorted(set().union(*[set(p) for p in probs]))
    total = 0.0
    pools = [[WILD] if r == forced_wild_reel else symbols for r in range(5)]
    for seq in product(*pools):
        pr = 1.0
        for r, sym in enumerate(seq):
            if r != forced_wild_reel:
                pr *= probs[r].get(sym, 0.0)
        if pr:
            total += pr * _line_best_win(list(seq))
    return total


def scatter_distribution() -> dict[int, float]:
    per_reel = []
    for strip in REEL_STRIPS:
        cnt = Counter()
        for stop in range(len(strip)):
            k = window_for_stop(strip, stop).count(SCATTER)
            cnt[k] += 1 / len(strip)
        per_reel.append(cnt)
    dist = {0: 1.0}
    for rd in per_reel:
        nxt = defaultdict(float)
        for a, pa in dist.items():
            for b, pb in rd.items():
                nxt[a+b] += pa*pb
        dist = dict(nxt)
    return dist


def theoretical_metrics(expansion_probability: float = EXPANDING_WILD_PROBABILITY) -> dict[str, float | dict[int,float]]:
    line_ev = expected_line_payout()
    base_line_rtp = len(PAYLINES) * line_ev
    sd = scatter_distribution()
    scatter_ev = sum(p * SCATTER_PAYTABLE.get(min(k,5),0.0) for k,p in sd.items() if k >= 3)
    base_rtp = base_line_rtp + scatter_ev
    bonus_frequency = sum(p for k,p in sd.items() if k >= 3)
    expected_fs_unconditional = sum(p * FREE_SPINS.get(min(k,5),0) for k,p in sd.items() if k >= 3)
    expanded_line_rtp = sum(len(PAYLINES)*expected_line_payout(r) for r in (1,2,3))/3
    free_spin_ev = ((1-expansion_probability)*base_line_rtp + expansion_probability*expanded_line_rtp + scatter_ev)
    bonus_rtp = expected_fs_unconditional * free_spin_ev
    return {
        "base_line_rtp": base_line_rtp,
        "scatter_rtp": scatter_ev,
        "base_rtp": base_rtp,
        "bonus_rtp": bonus_rtp,
        "total_rtp": base_rtp + bonus_rtp,
        "bonus_frequency": bonus_frequency,
        "average_free_spins_per_trigger": expected_fs_unconditional/bonus_frequency if bonus_frequency else 0.0,
        "free_spin_ev": free_spin_ev,
        "expanded_line_rtp": expanded_line_rtp,
        "scatter_distribution": sd,
    }
