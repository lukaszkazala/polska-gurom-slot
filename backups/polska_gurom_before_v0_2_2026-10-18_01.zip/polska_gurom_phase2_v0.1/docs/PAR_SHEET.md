# PAR_SHEET.md

**STATUS: PROTOTYPE / NOT MATH-FROZEN**

## Core parameters
| Parameter | Value |
|---|---:|
| Reels x rows | 5 x 3 |
| Fixed paylines | 20 |
| Strip length | 36 each |
| Max Win | 5000x |
| Hussar Charge probability | 25% per free spin |
| Eligible expanding reels | 2, 3, 4 |
| Target RTP | ~96.0% |
| Target base RTP | ~73.5% |
| Target bonus RTP | ~22.5% |
| Target hit frequency | 25%-30% |
| Target bonus frequency | 1/150-1/250 |

## Reel strip composition (all 5 reels)
| Symbol | Count | Stop probability |
|---|---:|---:|
| L1 | 7 | 19.444% |
| L2 | 5 | 13.889% |
| L3 | 5 | 13.889% |
| L4 | 4 | 11.111% |
| P1 | 4 | 11.111% |
| P2 | 3 | 8.333% |
| P3 | 3 | 8.333% |
| P4 | 2 | 5.556% |
| WILD | 2 | 5.556% |
| SCATTER | 1 | 2.778% |

## Paytable (x total bet)
| Symbol | 3 | 4 | 5 |
|---|---:|---:|---:|
| L1 | 0.20 | 0.80 | 2.50 |
| L2 | 0.25 | 1.00 | 3.50 |
| L3 | 0.30 | 1.20 | 4.50 |
| L4 | 0.40 | 1.60 | 6.00 |
| P1 | 0.60 | 2.50 | 10.00 |
| P2 | 0.80 | 3.50 | 15.00 |
| P3 | 1.20 | 5.50 | 25.00 |
| P4 | 2.00 | 10.00 | 50.00 |

Scatter: 3=1x / 4=5x / 5=20x. Free spins: 3=8 / 4=10 / 5=12.

## Exact theoretical result
| Metric | Result |
|---|---:|
| Theoretical RTP | 80.5417% |
| Base Game RTP | 74.4530% |
| Bonus RTP | 6.0887% |
| Base line RTP | 73.8482% |
| Scatter RTP | 0.6048% |
| Bonus frequency | 0.5088% (~1/196.55) |

## Development simulations — deterministic seed 20261015
| Spins | RTP | Base RTP | Bonus RTP | Hit Freq. | Bonus Freq. | Variance | Std Dev | Max Win |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 10,000 | 77.2715% | 73.1705% | 4.1010% | 49.4800% | 0.3500% | 4.5605 | 2.1355 | 75.55x |
| 100,000 | 80.3310% | 74.6472% | 5.6838% | 49.5490% | 0.4690% | 5.6924 | 2.3859 | 75.60x |
| 1,000,000 | 80.3087% | 74.3183% | 5.9903% | 49.6463% | 0.5130% | 5.5966 | 2.3657 | 130.00x |

## Interpretation
The base-game RTP is close to the intended ~73.5% allocation. The principal RTP deficit is the bonus: theoretical bonus RTP is only 6.09% versus the design allocation of ~22.5%. Raising the expansion probability alone cannot bridge the full gap under the current paytable; even a 100% expansion chance would remain below the total 96% target. A later tuning pass should therefore redesign the bonus economics (for example paytable shape/reel composition and/or an explicitly approved bonus-only amplifier) rather than merely forcing the event probability.

The hit frequency is ~49.65%, well above the 25%-30% target. The main cause is the high combined density of low symbols plus two Wild stops per reel across 20 paylines. A later tuning pass should reduce frequent low-tier line hits while preserving the base RTP through less frequent but larger awards.
