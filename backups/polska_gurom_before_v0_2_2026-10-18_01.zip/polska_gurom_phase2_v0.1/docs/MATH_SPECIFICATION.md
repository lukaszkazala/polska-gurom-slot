# MATH_SPECIFICATION.md

## Status
PROTOTYPE / NOT MATH-FROZEN

## Board and paylines
- Grid: 5 reels x 3 rows.
- 20 fixed paylines.
- Regular wins pay left-to-right from reel 1.
- Minimum 3 consecutive matching/substitutable symbols.
- 3/4/5-of-a-kind supported.
- Multiple paylines may pay in one spin.
- Each payline is evaluated once using the highest-paying valid regular-symbol interpretation; this prevents double-counting ambiguous Wild prefixes.

## Symbols
Regular: L1, L2, L3, L4, P1 (Pierogi), P2 (Stork), P3 (Sabre), P4 (Hussar).
Special: WILD, SCATTER. The math layer uses internal IDs only.

## Wild
WILD substitutes for L1-L4 and P1-P4. It never substitutes for SCATTER and has no independent Wild-only paytable. An all-Wild prefix is paid once as the highest-paying regular-symbol interpretation (P4 under the current prototype paytable).

## Scatter and bonus
SCATTER pays anywhere. Prototype Scatter pays: 3=1x, 4=5x, 5=20x total bet.
3/4/5 Scatters trigger 8/10/12 free spins. No retriggers.

## HUSSAR CHARGE
During each free spin, with prototype probability 25%, exactly one of reels 2, 3 or 4 is selected uniformly and converted to WILD for line evaluation. This probability is a tuning parameter, not a final value.
Prototype convention: Scatter count/payout is evaluated on the original generated grid before the expansion. Expansion affects payline evaluation only. This convention remains subject to review before Math Freeze.

## Max Win
Round payout is capped at 5000x total bet. The cap is applied after base plus free-spin aggregation.

## Reel strips
Each reel has 36 stops with identical composition but rotated ordering:
- L1: 7 (19.444%)
- L2: 5 (13.889%)
- L3: 5 (13.889%)
- L4: 4 (11.111%)
- P1: 4 (11.111%)
- P2: 3 (8.333%)
- P3: 3 (8.333%)
- P4: 2 (5.556%)
- WILD: 2 (5.556%)
- SCATTER: 1 (2.778%)

A single Scatter on a 36-stop reel appears in the 3-row window for 3 of 36 stops, so each reel has an 8.333% probability of showing one Scatter. Exact theoretical paid-spin bonus frequency is 0.005087770, approximately 1 in 196.55 spins.

## Prototype paytable (multiples of TOTAL BET)
| Symbol | 3 | 4 | 5 |
|---|---:|---:|---:|
| L1 | 0.20 | 0.80 | 2.50 |
| L2 | 0.25 | 1.00 | 3.50 |
| L3 | 0.30 | 1.20 | 4.50 |
| L4 | 0.40 | 1.60 | 6.00 |
| P1 | 0.60 | 2.50 | 10.00 |
| P2 | 0.80 | 3.50 | 15.00 |
| P3 | 1.20 | 5.50 | 25.00 |
| P4 | 2.00 | 10.00 | 50.00 |

Scatter: 3=1.00x, 4=5.00x, 5=20.00x.

## Theoretical metrics for prototype v0.1
- Base line RTP: 73.8482%
- Scatter RTP in paid game: 0.6048%
- Base Game RTP total: 74.4530%
- Bonus RTP: 6.0887%
- Total theoretical RTP: 80.5417%
- Exact bonus frequency: 0.5088% (~1/196.55)
- Average awarded free spins per trigger: 8.0900
- Expected free-spin payout: 1.4793x per free spin

The theoretical RTP is computed analytically from per-reel symbol probabilities, exact line expectation, exact Scatter-count distribution and expected free-spin value under the prototype 25% expanding-reel probability.

## Targets vs current prototype
Target total RTP is approximately 96%, with initial design allocation approximately 73.5% base / 22.5% bonus. Current base RTP is already close to the base allocation, but bonus RTP is far below target. Total theoretical RTP is therefore substantially low.

Target hit frequency is 25%-30%. The 1M simulation gives 49.6463%, so the current reel/paytable structure produces too many small wins.

## Unresolved tuning parameters
- Paytable values.
- Reel symbol counts/order, especially regular/Wild density.
- HUSSAR CHARGE expansion probability.
- Scatter pay values.
- Potential bonus-only payout amplification if approved in later design review.
- Exact convention for Scatter interaction with expanding Wild reel before Math Freeze.

REQUIRE_CURRENT_STAKE_SDK_VERIFICATION before SDK-specific integration.
