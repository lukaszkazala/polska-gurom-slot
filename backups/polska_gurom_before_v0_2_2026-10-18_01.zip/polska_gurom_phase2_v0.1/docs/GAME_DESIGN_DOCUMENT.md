# POLSKA GUROM v0.1 — Approved Game Design

Target: Stake Engine. Status: prototype / not math-frozen.

- Board: 5 reels × 3 rows; 20 fixed paylines.
- Symbols: L1-L4, P1 Pierogi, P2 Stork, P3 Sabre, P4 Hussar, WILD, SCATTER.
- Wild substitutes L1-L4/P1-P4, never Scatter, no separate Wild-only prize.
- Scatter pays anywhere; 3/4/5 award 8/10/12 free spins.
- Bonus: HUSSAR CHARGE; max one expanding Wild reel on reel 2, 3 or 4 per free spin.
- No retriggers, jackpots, gamble feature, or persistent progression in v0.1.
- Target RTP ~96% (initial allocation ~73.5% base / ~22.5% bonus).
- Target volatility medium-high, hit frequency 25%-30%, bonus approximately 1/150-1/250.
- Max Win: 5000× total bet.
- Frontend must not generate mathematical randomness.

REQUIRE_CURRENT_STAKE_SDK_VERIFICATION before SDK-specific integration.
