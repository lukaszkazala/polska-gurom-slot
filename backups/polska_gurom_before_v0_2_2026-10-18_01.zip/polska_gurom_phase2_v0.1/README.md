# POLSKA GUROM — Mathematical Prototype v0.1

Pure-Python Phase 2 prototype for validating slot mathematics before Stake Engine SDK integration.
No frontend, payments, publishing, or real-money functionality is included.

Run tests: `pytest -q`

The current Stake Engine SDK integration point is intentionally deferred and marked for current-SDK verification.
