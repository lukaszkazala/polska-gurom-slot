import random
from polska_gurom.config import *
from polska_gurom.game import *
from polska_gurom.game import _line_best_win
from polska_gurom.sim import simulate


def blank(sym="SCATTER"):
    return [[sym for _ in range(5)] for _ in range(3)]

def grid_from_rows(rows): return [list(r) for r in rows]

def test_strip_composition_and_dimensions():
    expected={"L1":7,"L2":5,"L3":5,"L4":4,"P1":4,"P2":3,"P3":3,"P4":2,"WILD":2,"SCATTER":1}
    assert len(REEL_STRIPS)==5 and all(len(r)==36 for r in REEL_STRIPS)
    for strip in REEL_STRIPS:
        assert {s:strip.count(s) for s in SYMBOLS} == expected
    assert len(PAYLINES)==20

def test_complete_loss():
    g=grid_from_rows([["L1","L2","L3","L4","P1"]]*3)
    assert evaluate_paid_spin(g).payout == 0

def _straight_center(symbols):
    return grid_from_rows([["SCATTER"]*5, symbols, ["SCATTER"]*5])

def test_three_four_five_kind():
    assert evaluate_lines(_straight_center(["P1","P1","P1","L1","L2"])) >= PAYTABLE["P1"][3]
    assert evaluate_lines(_straight_center(["P1","P1","P1","P1","L2"])) >= PAYTABLE["P1"][4]
    assert evaluate_lines(_straight_center(["P1"]*5)) >= PAYTABLE["P1"][5]

def test_wild_substitution():
    g=_straight_center(["P2","WILD","P2","L1","L2"])
    assert evaluate_lines(g) >= PAYTABLE["P2"][3]

def test_wild_does_not_substitute_scatter():
    g=grid_from_rows([["SCATTER","WILD","SCATTER","L1","L2"], ["L1","L2","L3","L4","P1"], ["L2","L3","L4","P1","P2"]])
    assert count_scatter(g)==2
    assert not evaluate_paid_spin(g).bonus_triggered

def test_multiple_paylines_and_aggregation():
    g=grid_from_rows([["L1"]*5,["L1"]*5,["L1"]*5])
    assert evaluate_lines(g) > PAYTABLE["L1"][5]

def test_no_double_counting_best_wild_interpretation():
    g=_straight_center(["WILD","WILD","WILD","L1","L2"])
    # Center line all-wild prefix is paid once as the best regular-symbol interpretation.
    assert _line_best_win(["WILD","WILD","WILD","L1","L2"]) == PAYTABLE["P4"][3]

def test_scatter_3_4_5():
    for n,fs in [(3,8),(4,10),(5,12)]:
        g=grid_from_rows([["L1"]*5,["L2"]*5,["L3"]*5])
        for i in range(n): g[i//5][i%5]="SCATTER"
        r=evaluate_paid_spin(g)
        assert r.scatter_count==n and r.free_spins_awarded==fs

def test_bonus_no_expanding_wild():
    g=grid_from_rows([["L1"]*5,["P1"]*5,["L2"]*5])
    r=evaluate_free_spin(g, random.Random(1), 0.0)
    assert r.expanding_reel is None

def test_bonus_with_expanding_wild():
    g=grid_from_rows([["L1"]*5,["P1"]*5,["L2"]*5])
    r=evaluate_free_spin(g, random.Random(1), 1.0)
    assert r.expanding_reel in (1,2,3)

def test_max_win_cap():
    # Monkey-free construction: 15 wilds creates many P4 line wins but remains below cap;
    # explicit aggregation cap is guaranteed by paid-spin and round functions.
    g=grid_from_rows([["WILD"]*5]*3)
    r=evaluate_paid_spin(g)
    assert r.payout <= MAX_WIN
    assert cap_payout(6000.0)==MAX_WIN

def test_deterministic_simulation():
    a=simulate(500, seed=123)
    b=simulate(500, seed=123)
    assert a==b
