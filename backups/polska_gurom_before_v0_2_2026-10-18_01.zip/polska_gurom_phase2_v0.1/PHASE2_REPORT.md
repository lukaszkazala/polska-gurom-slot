# POLSKA GUROM v0.1 — PHASE 2 Report

Status: prototype / not math-frozen.

- Tests: 12/12 passed.
- Theoretical RTP: 80.5417%
- Theoretical Base Game RTP: 74.4530%
- Theoretical Bonus RTP: 6.0887%
- Exact theoretical bonus frequency: 0.5088% (~1 in 196.55)

Deterministic simulations, seed 20261015:
- 10k: RTP 77.2715%, base 73.1705%, bonus 4.1010%, hit 49.4800%, bonus 0.3500%, variance 4.5605, std dev 2.1355, max 75.55x.
- 100k: RTP 80.3311%, base 74.6472%, bonus 5.6838%, hit 49.5490%, bonus 0.4690%, variance 5.6924, std dev 2.3859, max 75.60x.
- 1M: RTP 80.3087%, base 74.3183%, bonus 5.9903%, hit 49.6463%, bonus 0.5130%, variance 5.5966, std dev 2.3657, max 130.00x.

Conclusion: base allocation is close to the design intent, but bonus contribution is far too low and hit frequency far too high. No tuning was performed after observing these results.
